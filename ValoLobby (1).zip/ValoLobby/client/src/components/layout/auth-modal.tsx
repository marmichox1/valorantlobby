import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { loginSchema, registerSchema } from "@shared/schema";
import type { LoginCredentials, RegisterData } from "@shared/schema";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  const { login, register: registerUser } = useAuth();
  const { toast } = useToast();

  // Login form setup
  const loginForm = useForm<LoginCredentials>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });

  // Register form setup
  const registerForm = useForm<RegisterData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      displayName: "",
      photoURL: "",
      currentRank: "unranked"
    }
  });

  // Handle login submission
  const onLoginSubmit = async (data: LoginCredentials) => {
    const user = await login(data);
    if (user) {
      onClose();
    }
  };

  // Handle register submission
  const onRegisterSubmit = async (data: RegisterData) => {
    const user = await registerUser(data);
    if (user) {
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-[#1F2326] border-[#FF4655]/20">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-[#F9F9F9]">Authentication</DialogTitle>
          <DialogDescription className="text-[#F9F9F9]/70">
            Sign in or create an account to use Valorant Lobby Finder
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "login" | "register")} className="w-full">
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Register</TabsTrigger>
          </TabsList>

          {/* Login Form */}
          <TabsContent value="login" className="space-y-4">
            <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  {...loginForm.register("email")}
                  className="bg-[#0F1923] border-[#28557F]"
                />
                {loginForm.formState.errors.email && (
                  <p className="text-[#FF4655] text-sm">{loginForm.formState.errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input 
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  {...loginForm.register("password")}
                  className="bg-[#0F1923] border-[#28557F]"
                />
                {loginForm.formState.errors.password && (
                  <p className="text-[#FF4655] text-sm">{loginForm.formState.errors.password.message}</p>
                )}
              </div>

              <Button 
                type="submit" 
                className="w-full"
                variant="valorant"
                disabled={loginForm.formState.isSubmitting}
              >
                {loginForm.formState.isSubmitting ? "Logging in..." : "Login"}
              </Button>
            </form>
          </TabsContent>

          {/* Register Form */}
          <TabsContent value="register" className="space-y-4">
            <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input 
                    id="username"
                    placeholder="valorant_pro"
                    {...registerForm.register("username")}
                    className="bg-[#0F1923] border-[#28557F]"
                  />
                  {registerForm.formState.errors.username && (
                    <p className="text-[#FF4655] text-sm">{registerForm.formState.errors.username.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="displayName">Display Name</Label>
                  <Input 
                    id="displayName"
                    placeholder="Pro Player"
                    {...registerForm.register("displayName")}
                    className="bg-[#0F1923] border-[#28557F]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reg-email">Email</Label>
                <Input 
                  id="reg-email"
                  type="email"
                  placeholder="your.email@example.com"
                  {...registerForm.register("email")}
                  className="bg-[#0F1923] border-[#28557F]"
                />
                {registerForm.formState.errors.email && (
                  <p className="text-[#FF4655] text-sm">{registerForm.formState.errors.email.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="reg-password">Password</Label>
                  <Input 
                    id="reg-password"
                    type="password"
                    placeholder="••••••••"
                    {...registerForm.register("password")}
                    className="bg-[#0F1923] border-[#28557F]"
                  />
                  {registerForm.formState.errors.password && (
                    <p className="text-[#FF4655] text-sm">{registerForm.formState.errors.password.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input 
                    id="confirmPassword"
                    type="password"
                    placeholder="••••••••"
                    {...registerForm.register("confirmPassword")}
                    className="bg-[#0F1923] border-[#28557F]"
                  />
                  {registerForm.formState.errors.confirmPassword && (
                    <p className="text-[#FF4655] text-sm">{registerForm.formState.errors.confirmPassword.message}</p>
                  )}
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full"
                variant="valorant"
                disabled={registerForm.formState.isSubmitting}
              >
                {registerForm.formState.isSubmitting ? "Creating Account..." : "Create Account"}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}