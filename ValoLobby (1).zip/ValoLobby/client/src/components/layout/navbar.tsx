import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import AuthModal from "./auth-modal";
import { formatRank, getRankColor } from "@/lib/utils";
import { Menu, X, User, LogOut, Grid } from "lucide-react";

export default function Navbar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Close mobile menu when changing location
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);
  
  const isActive = (path: string) => location === path;
  
  return (
    <nav className="bg-[#1F2326] border-b border-[#FF4655]/20 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <div className="flex items-center cursor-pointer">
                  <div className="text-[#FF4655] text-2xl font-display font-bold tracking-wider font-['Tungsten']">VALORANT</div>
                  <div className="ml-2 text-[#F9F9F9] text-sm font-bold tracking-wide font-['DIN Next']">LOBBY FINDER</div>
                </div>
              </Link>
            </div>
            
            {/* Desktop navigation */}
            <div className="hidden md:ml-8 md:flex md:space-x-8">
              <Link href="/">
                <div className={`border-b-2 px-1 pt-1 text-sm font-medium cursor-pointer ${
                  isActive('/') 
                    ? 'border-[#FF4655] text-[#F9F9F9]' 
                    : 'border-transparent text-[#F9F9F9]/70 hover:border-[#FF4655]/50 hover:text-[#F9F9F9]'
                }`}>
                  Find Lobbies
                </div>
              </Link>
              {user && (
                <Link href="/my-lobbies">
                  <div className={`border-b-2 px-1 pt-1 text-sm font-medium cursor-pointer ${
                    isActive('/my-lobbies') 
                      ? 'border-[#FF4655] text-[#F9F9F9]' 
                      : 'border-transparent text-[#F9F9F9]/70 hover:border-[#FF4655]/50 hover:text-[#F9F9F9]'
                  }`}>
                    My Lobbies
                  </div>
                </Link>
              )}
              {user && (
                <Link href="/profile">
                  <div className={`border-b-2 px-1 pt-1 text-sm font-medium cursor-pointer ${
                    isActive('/profile') 
                      ? 'border-[#FF4655] text-[#F9F9F9]' 
                      : 'border-transparent text-[#F9F9F9]/70 hover:border-[#FF4655]/50 hover:text-[#F9F9F9]'
                  }`}>
                    Profile
                  </div>
                </Link>
              )}
            </div>
          </div>
          
          <div className="flex items-center">
            {/* Desktop user actions */}
            {user ? (
              <div className="hidden md:flex items-center">
                <div className="flex items-center bg-[#0F1923] border border-[#383E3A]/30 rounded-md px-3 py-1 mr-4">
                  {user.currentRank ? (
                    <div className={`w-7 h-7 rounded-full ${getRankColor(user.currentRank).bg} flex items-center justify-center ${getRankColor(user.currentRank).text} text-xs font-bold`}>
                      {formatRank(user.currentRank)}
                    </div>
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-gray-700 flex items-center justify-center text-gray-300 text-xs font-bold">
                      U
                    </div>
                  )}
                  <span className="ml-2 text-sm font-medium">{user.displayName || user.username}</span>
                </div>
                <Button 
                  variant="destructive"
                  size="sm"
                  className="bg-[#FF4655] hover:bg-[#FF4655]/80"
                  onClick={() => logout()}
                >
                  <LogOut className="w-4 h-4 mr-2" /> Logout
                </Button>
              </div>
            ) : (
              <div className="hidden md:block">
                <Button 
                  size="sm"
                  className="bg-[#FF4655] hover:bg-[#FF4655]/80 text-white font-bold px-5"
                  onClick={() => setShowAuthModal(true)}
                >
                  LOGIN
                </Button>
              </div>
            )}
            
            {/* Mobile menu button */}
            <div className="md:hidden flex items-center">
              {user && (
                <div className="flex items-center mr-2">
                  <div className={`w-7 h-7 rounded-full ${
                    user.currentRank ? getRankColor(user.currentRank).bg : 'bg-gray-700'
                  } flex items-center justify-center ${
                    user.currentRank ? getRankColor(user.currentRank).text : 'text-gray-300'
                  } text-xs font-bold`}>
                    {user.currentRank ? formatRank(user.currentRank) : 'U'}
                  </div>
                </div>
              )}
              
              {!user && (
                <Button 
                  size="sm"
                  className="bg-[#FF4655] hover:bg-[#FF4655]/80 text-white font-bold mr-2"
                  onClick={() => setShowAuthModal(true)}
                >
                  LOGIN
                </Button>
              )}
              
              <button 
                className="inline-flex items-center justify-center p-2 rounded-md text-[#F9F9F9] hover:bg-[#0F1923] focus:outline-none transition-colors"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0F1923] border-t border-[#FF4655]/20 shadow-lg">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <Link href="/">
              <div className={`block px-3 py-2 rounded-md text-base font-medium ${
                isActive('/') 
                  ? 'bg-[#FF4655]/10 text-[#FF4655]' 
                  : 'text-[#F9F9F9]/80 hover:bg-[#1F2326] hover:text-[#F9F9F9]'
              }`}>
                <Grid className="inline-block w-4 h-4 mr-2" />
                Find Lobbies
              </div>
            </Link>
            
            {user && (
              <>
                <Link href="/my-lobbies">
                  <div className={`block px-3 py-2 rounded-md text-base font-medium ${
                    isActive('/my-lobbies') 
                      ? 'bg-[#FF4655]/10 text-[#FF4655]' 
                      : 'text-[#F9F9F9]/80 hover:bg-[#1F2326] hover:text-[#F9F9F9]'
                  }`}>
                    <Grid className="inline-block w-4 h-4 mr-2" />
                    My Lobbies
                  </div>
                </Link>
                
                <Link href="/profile">
                  <div className={`block px-3 py-2 rounded-md text-base font-medium ${
                    isActive('/profile') 
                      ? 'bg-[#FF4655]/10 text-[#FF4655]' 
                      : 'text-[#F9F9F9]/80 hover:bg-[#1F2326] hover:text-[#F9F9F9]'
                  }`}>
                    <User className="inline-block w-4 h-4 mr-2" />
                    Profile
                  </div>
                </Link>
                
                <div 
                  className="block px-3 py-2 rounded-md text-base font-medium text-[#F9F9F9]/80 hover:bg-[#1F2326] hover:text-[#F9F9F9] cursor-pointer"
                  onClick={() => logout()}
                >
                  <LogOut className="inline-block w-4 h-4 mr-2" />
                  Logout
                </div>
              </>
            )}
          </div>
        </div>
      )}
      
      {/* Auth Modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </nav>
  );
}
