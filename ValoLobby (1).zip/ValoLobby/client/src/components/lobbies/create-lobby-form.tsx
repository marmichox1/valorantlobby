import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/lib/auth";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { GameType, Rank } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";

const formSchema = z.object({
  gameType: z.nativeEnum(GameType),
  playersNeeded: z.number().min(1).max(4),
  code: z.string().length(6).regex(/^[A-Z0-9]+$/, "Code must be 6 alphanumeric characters (uppercase)"),
  disableRankRestrictions: z.boolean().default(false),
  minRank: z.nativeEnum(Rank),
  maxRank: z.nativeEnum(Rank),
  description: z.string().optional(),
  expirationMinutes: z.number(),
}).refine(data => {
  // Skip validation if rank restrictions are disabled
  if (data.disableRankRestrictions) return true;
  
  // Compare using indices in the enum
  const rankValues = Object.values(Rank);
  const minRankIndex = rankValues.indexOf(data.minRank);
  const maxRankIndex = rankValues.indexOf(data.maxRank);
  return maxRankIndex >= minRankIndex;
}, {
  message: "Maximum rank must be higher than or equal to minimum rank",
  path: ["maxRank"],
});

type FormValues = z.infer<typeof formSchema>;

export default function CreateLobbyForm() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // No longer generating random code, user will enter it manually

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      gameType: GameType.UNRATED,
      playersNeeded: 4,
      code: "",
      disableRankRestrictions: false,
      minRank: Rank.UNRANKED,
      maxRank: Rank.RADIANT,
      description: "",
      expirationMinutes: 60,
    },
  });
  
  const createLobbyMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      if (!user) throw new Error("You must be logged in to create a lobby");
      
      const res = await apiRequest("POST", "/api/lobbies", {
        ...values,
        // ownerId is already handled by the session cookies
      });
      
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Lobby created!",
        description: "Your lobby has been created successfully.",
      });
      
      // Reset form with appropriate default values
      form.reset({
        gameType: GameType.UNRATED,
        playersNeeded: 4, // The default is 4 players for regular game modes
        code: "",
        disableRankRestrictions: false,
        minRank: Rank.UNRANKED,
        maxRank: Rank.RADIANT,
        description: "",
        expirationMinutes: 60,
      });
      
      // Invalidate lobbies query to refresh the list
      queryClient.invalidateQueries({ queryKey: ["/api/lobbies"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating lobby",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: FormValues) => {
    createLobbyMutation.mutate(values);
  };
  
  if (!user) {
    return (
      <Card className="bg-[#1F2326]/50 p-6 max-w-2xl mx-auto">
        <div className="text-center p-8">
          <h2 className="text-xl font-bold mb-2">Sign In Required</h2>
          <p className="text-[#F9F9F9]/70 mb-4">You need to sign in to create a lobby</p>
        </div>
      </Card>
    );
  }
  
  const rankOptions = Object.entries(Rank).map(([key, value]) => ({
    label: key.replace('_', ' ').split(' ').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    ).join(' '),
    value
  }));
  
  return (
    <Card className="bg-[#1F2326]/50 p-6 max-w-2xl mx-auto">
      <h2 className="text-xl font-bold mb-6 text-[#F9F9F9]">Create New Lobby</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Game Type Selection */}
          <FormField
            control={form.control}
            name="gameType"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-[#F9F9F9]/80 text-sm font-medium">Game Type</FormLabel>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  <div className="relative">
                    <input 
                      type="radio" 
                      id="game-unrated" 
                      className="sr-only peer" 
                      checked={field.value === GameType.UNRATED}
                      onChange={() => {
                        field.onChange(GameType.UNRATED);
                        // Ensure playersNeeded is valid for the selected game type
                        const currentPlayers = form.getValues("playersNeeded");
                        if (currentPlayers > 4) {
                          form.setValue("playersNeeded", 4);
                        }
                      }}
                    />
                    <label 
                      htmlFor="game-unrated" 
                      className="flex flex-col items-center justify-center border border-[#383E3A]/30 rounded-md p-4 cursor-pointer hover:border-[#28557F] peer-checked:border-[#28557F] peer-checked:bg-[#28557F]/10"
                    >
                      <img src="/src/assets/game-modes/unrated.svg" className="h-5 w-5 mb-2" alt="Unrated" />
                      <span className="text-sm font-medium">Unrated</span>
                    </label>
                  </div>
                  
                  <div className="relative">
                    <input 
                      type="radio" 
                      id="game-competitive" 
                      className="sr-only peer"
                      checked={field.value === GameType.COMPETITIVE}
                      onChange={() => {
                        field.onChange(GameType.COMPETITIVE);
                        // Ensure playersNeeded is valid for the selected game type
                        const currentPlayers = form.getValues("playersNeeded");
                        if (currentPlayers > 4) {
                          form.setValue("playersNeeded", 4);
                        }
                      }}
                    />
                    <label 
                      htmlFor="game-competitive" 
                      className="flex flex-col items-center justify-center border border-[#383E3A]/30 rounded-md p-4 cursor-pointer hover:border-[#FF4655] peer-checked:border-[#FF4655] peer-checked:bg-[#FF4655]/10"
                    >
                      <img src="/src/assets/game-modes/competitive.svg" className="h-5 w-5 mb-2" alt="Competitive" />
                      <span className="text-sm font-medium">Competitive</span>
                    </label>
                  </div>
                  
                  <div className="relative">
                    <input 
                      type="radio" 
                      id="game-spikerush" 
                      className="sr-only peer"
                      checked={field.value === GameType.SPIKE_RUSH}
                      onChange={() => {
                        field.onChange(GameType.SPIKE_RUSH);
                        // Ensure playersNeeded is valid for the selected game type
                        const currentPlayers = form.getValues("playersNeeded");
                        if (currentPlayers > 4) {
                          form.setValue("playersNeeded", 4);
                        }
                      }}
                    />
                    <label 
                      htmlFor="game-spikerush" 
                      className="flex flex-col items-center justify-center border border-[#383E3A]/30 rounded-md p-4 cursor-pointer hover:border-green-500 peer-checked:border-green-500 peer-checked:bg-green-500/10"
                    >
                      <img src="/src/assets/game-modes/spike-rush.svg" className="h-5 w-5 mb-2" alt="Spike Rush" />
                      <span className="text-sm font-medium">Spike Rush</span>
                    </label>
                  </div>
                  
                  <div className="relative">
                    <input 
                      type="radio" 
                      id="game-swiftplay" 
                      className="sr-only peer"
                      checked={field.value === GameType.SWIFTPLAY}
                      onChange={() => {
                        field.onChange(GameType.SWIFTPLAY);
                        // Ensure playersNeeded is valid for the selected game type
                        const currentPlayers = form.getValues("playersNeeded");
                        if (currentPlayers > 4) {
                          form.setValue("playersNeeded", 4);
                        }
                      }}
                    />
                    <label 
                      htmlFor="game-swiftplay" 
                      className="flex flex-col items-center justify-center border border-[#383E3A]/30 rounded-md p-4 cursor-pointer hover:border-purple-500 peer-checked:border-purple-500 peer-checked:bg-purple-500/10"
                    >
                      <img src="/src/assets/game-modes/swiftplay.svg" className="h-5 w-5 mb-2" alt="Swiftplay" />
                      <span className="text-sm font-medium">Swiftplay</span>
                    </label>
                  </div>
                  
                  <div className="relative">
                    <input 
                      type="radio" 
                      id="game-custom" 
                      className="sr-only peer"
                      checked={field.value === GameType.CUSTOM}
                      onChange={() => {
                        field.onChange(GameType.CUSTOM);
                        // No need to adjust player count for custom mode as it can have up to 9 players
                      }}
                    />
                    <label 
                      htmlFor="game-custom" 
                      className="flex flex-col items-center justify-center border border-[#383E3A]/30 rounded-md p-4 cursor-pointer hover:border-yellow-500 peer-checked:border-yellow-500 peer-checked:bg-yellow-500/10"
                    >
                      <img src="/src/assets/game-modes/custom.svg" className="h-5 w-5 mb-2" alt="Custom" />
                      <span className="text-sm font-medium">Custom</span>
                    </label>
                  </div>
                </div>
              </FormItem>
            )}
          />
          
          {/* Players Needed and Expiration */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="playersNeeded"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-[#F9F9F9]/80 text-sm font-medium">Players Needed</FormLabel>
                  <Select
                    value={field.value.toString()}
                    onValueChange={(value) => field.onChange(parseInt(value))}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select players needed" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {form.watch("gameType") === GameType.CUSTOM ? (
                        <>
                          <SelectItem value="1">1 more player</SelectItem>
                          <SelectItem value="2">2 more players</SelectItem>
                          <SelectItem value="3">3 more players</SelectItem>
                          <SelectItem value="4">4 more players</SelectItem>
                          <SelectItem value="5">5 more players</SelectItem>
                          <SelectItem value="6">6 more players</SelectItem>
                          <SelectItem value="7">7 more players</SelectItem>
                          <SelectItem value="8">8 more players</SelectItem>
                          <SelectItem value="9">9 more players</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="1">1 more player</SelectItem>
                          <SelectItem value="2">2 more players</SelectItem>
                          <SelectItem value="3">3 more players</SelectItem>
                          <SelectItem value="4">4 more players</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="expirationMinutes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-[#F9F9F9]/80 text-sm font-medium">Lobby Expiration</FormLabel>
                  <Select
                    value={field.value.toString()}
                    onValueChange={(value) => field.onChange(parseInt(value))}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select expiration time" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                      <SelectItem value="120">2 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
          </div>
          
          {/* Lobby Code */}
          <FormField
            control={form.control}
            name="code"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-[#F9F9F9]/80 text-sm font-medium">Lobby Code</FormLabel>
                <FormControl>
                  <Input
                    placeholder="6-character code (A-Z, 0-9)"
                    maxLength={6}
                    className="font-mono tracking-wider text-center uppercase"
                    {...field}
                    onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                  />
                </FormControl>
                <div className="text-xs text-[#F9F9F9]/60 mt-1">
                  Enter a unique 6-character code for your lobby (A-Z, 0-9)
                </div>
              </FormItem>
            )}
          />
          
          {/* Disable Rank Restrictions */}
          <FormField
            control={form.control}
            name="disableRankRestrictions"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center space-x-3 space-y-0 mt-4">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel className="text-[#F9F9F9]/80 font-medium">
                    Allow all ranks to join
                  </FormLabel>
                  <p className="text-xs text-[#F9F9F9]/60">
                    When checked, rank restrictions will be ignored and players of any rank can join
                  </p>
                </div>
              </FormItem>
            )}
          />
          
          {/* Rank Requirements */}
          <div className={`grid grid-cols-2 gap-6 ${form.watch("disableRankRestrictions") ? "opacity-50 pointer-events-none" : ""}`}>
            <FormField
              control={form.control}
              name="minRank"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-[#F9F9F9]/80 text-sm font-medium">Minimum Rank</FormLabel>
                  <Select
                    value={field.value}
                    onValueChange={(value) => field.onChange(value as Rank)}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Minimum rank" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {rankOptions.map((rank) => (
                        <SelectItem key={rank.value} value={rank.value}>
                          {rank.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="maxRank"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-[#F9F9F9]/80 text-sm font-medium">Maximum Rank</FormLabel>
                  <Select
                    value={field.value}
                    onValueChange={(value) => field.onChange(value as Rank)}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Maximum rank" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {rankOptions.map((rank) => (
                        <SelectItem key={rank.value} value={rank.value}>
                          {rank.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
          </div>
          
          {/* Description */}
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-[#F9F9F9]/80 text-sm font-medium">Description (Optional)</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Add any additional information about your lobby..."
                    className="h-24"
                    {...field}
                  />
                </FormControl>
              </FormItem>
            )}
          />
          
          {/* Create Button */}
          <div className="flex justify-center">
            <Button 
              type="submit" 
              variant="valorant" 
              size="lg"
              disabled={createLobbyMutation.isPending}
              className="font-medium py-3 px-8 text-md tracking-wide"
            >
              {createLobbyMutation.isPending ? "CREATING..." : "CREATE LOBBY"}
            </Button>
          </div>
        </form>
      </Form>
    </Card>
  );
}