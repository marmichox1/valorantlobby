import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { GameType, Rank } from "@shared/schema";
import { Filter } from "lucide-react";

interface FilterSectionProps {
  gameTypeFilter: string | null;
  setGameTypeFilter: (gameType: string | null) => void;
  rankFilters: string[];
  setRankFilters: (ranks: string[]) => void;
  playersNeededFilter: number | null;
  setPlayersNeededFilter: (count: number | null) => void;
  lobbyCodeFilter: string;
  setLobbyCodeFilter: (code: string) => void;
}

export default function FilterSection({
  gameTypeFilter,
  setGameTypeFilter,
  rankFilters,
  setRankFilters,
  playersNeededFilter,
  setPlayersNeededFilter,
}: FilterSectionProps) {
  
  const toggleRankFilter = (rank: string) => {
    if (rankFilters.includes(rank)) {
      setRankFilters(rankFilters.filter(r => r !== rank));
    } else {
      setRankFilters([...rankFilters, rank]);
    }
  };
  
  const gameTypes = [
    { value: GameType.UNRATED, label: "Unrated" },
    { value: GameType.COMPETITIVE, label: "Competitive" },
    { value: GameType.SPIKE_RUSH, label: "Spike Rush" },
    { value: GameType.SWIFTPLAY, label: "Swiftplay" },
    { value: GameType.CUSTOM, label: "Custom" }
  ];
  
  const rankTiers = [
    { value: Rank.IRON_1, label: "Iron", color: "border-[#72767D]" },
    { value: Rank.BRONZE_1, label: "Bronze", color: "border-[#B97551]" },
    { value: Rank.SILVER_1, label: "Silver", color: "border-[#BEBEBE]" },
    { value: Rank.GOLD_1, label: "Gold", color: "border-[#EFB058]" },
    { value: Rank.PLATINUM_1, label: "Platinum", color: "border-[#4DF8E8]" },
    { value: Rank.DIAMOND_1, label: "Diamond", color: "border-[#B073FF]" },
    { value: Rank.ASCENDANT_1, label: "Ascendant", color: "border-[#59BB7C]" },
    { value: Rank.IMMORTAL_1, label: "Immortal", color: "border-[#EF4181]" },
    { value: Rank.RADIANT, label: "Radiant", color: "border-[#FFFFA8]" }
  ];
  
  return (
    <Card className="bg-[#1F2326]/50 p-4 mb-6 border-[#383E3A]/30">
      <div className="flex items-center mb-3">
        <Filter className="w-4 h-4 mr-2 text-[#FF4655]" />
        <h2 className="text-[#F9F9F9] text-lg font-bold">Filter Lobbies</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Game Type Filter */}
        <div>
          <h3 className="text-[#F9F9F9]/80 text-xs font-bold uppercase tracking-wide mb-2">Game Type</h3>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              className={`text-xs ${gameTypeFilter === null ? 'border-[#FF4655] text-[#FF4655] bg-[#FF4655]/10' : ''}`}
              onClick={() => setGameTypeFilter(null)}
            >
              All
            </Button>
            
            {gameTypes.map((type) => (
              <Button
                key={type.value}
                variant="outline"
                size="sm"
                className={`text-xs ${gameTypeFilter === type.value ? 'border-[#FF4655] text-[#FF4655] bg-[#FF4655]/10' : ''}`}
                onClick={() => setGameTypeFilter(type.value)}
              >
                {type.label}
              </Button>
            ))}
          </div>
        </div>
        
        {/* Rank Filter */}
        <div>
          <h3 className="text-[#F9F9F9]/80 text-xs font-bold uppercase tracking-wide mb-2">Rank Requirements</h3>
          <div className="flex flex-wrap gap-2">
            {rankTiers.map((rank) => (
              <Button
                key={rank.value}
                variant="outline"
                size="sm"
                className={`text-xs ${rankFilters.includes(rank.value) ? 'border-[#FF4655] text-[#FF4655] bg-[#FF4655]/10' : rank.color}`}
                onClick={() => toggleRankFilter(rank.value)}
              >
                {rank.label}
              </Button>
            ))}
          </div>
        </div>
        
        {/* Players Needed Filter */}
        <div>
          <h3 className="text-[#F9F9F9]/80 text-xs font-bold uppercase tracking-wide mb-2">Players Needed</h3>
          <Select 
            value={playersNeededFilter?.toString() || "any"} 
            onValueChange={(value) => setPlayersNeededFilter(value === "any" ? null : parseInt(value))}
          >
            <SelectTrigger className="bg-[#0F1923] border-[#383E3A]/30">
              <SelectValue placeholder="Any number" />
            </SelectTrigger>
            <SelectContent className="bg-[#0F1923] border-[#383E3A]">
              <SelectItem value="any">Any number</SelectItem>
              <SelectItem value="1">1 player</SelectItem>
              <SelectItem value="2">2 players</SelectItem>
              <SelectItem value="3">3 players</SelectItem>
              <SelectItem value="4">4 players</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </Card>
  );
}
