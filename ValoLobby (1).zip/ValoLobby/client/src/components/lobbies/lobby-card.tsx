import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { formatGameType, formatRank, formatTimeLeft, getGameTypeColor, getRankColor } from "@/lib/utils";
import type { LobbyWithOwner } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Users, Clock, User } from "lucide-react";

interface LobbyCardProps {
  lobby: LobbyWithOwner;
}

export default function LobbyCard({ lobby }: LobbyCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const gameTypeColors = getGameTypeColor(lobby.gameType);
  
  // Join lobby mutation
  const joinMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("You must be logged in to join a lobby");
      const res = await apiRequest("POST", `/api/lobbies/${lobby.id}/join`, { userId: user.id });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lobbies"] });
      toast({
        title: "Success!",
        description: "You have joined the lobby",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleJoinLobby = () => {
    joinMutation.mutate();
  };
  
  // Format current players
  const totalPlayers = lobby.gameType === 'custom' ? 10 : 5;
  const currentPlayers = lobby.currentPlayers || 0;
  
  // Check if current user is owner
  const isOwner = user?.id === lobby.ownerId;
  
  // Check if lobby is full
  const isFull = currentPlayers >= totalPlayers;
  
  return (
    <Card className="bg-[#1F2326] border-[#383E3A]/30 overflow-hidden hover:shadow-lg hover:shadow-[#FF4655]/5 transition-all duration-200 flex flex-col h-full">
      {/* Header with game type */}
      <div className={`bg-gradient-to-r ${gameTypeColors.gradient} to-transparent px-4 py-3 flex justify-between items-center border-b border-[#383E3A]/30`}>
        <div className="flex items-center">
          <div className="flex items-center">
            <img 
              src={`/src/assets/game-modes/${lobby.gameType === 'spike_rush' ? 'spike-rush' : lobby.gameType}.svg`} 
              alt={formatGameType(lobby.gameType)} 
              className="w-4 h-4 mr-2"
            />
            <span className={`font-medium text-sm ${gameTypeColors.text}`}>{formatGameType(lobby.gameType)}</span>
          </div>
          <span className="mx-2 text-[#F9F9F9]/40">•</span>
          <div className={`flex items-center ${gameTypeColors.bg} px-2 py-0.5 rounded-sm`}>
            <Users className="h-3.5 w-3.5 text-[#F9F9F9]/70 mr-1" />
            <span className="text-[#F9F9F9] text-xs">{currentPlayers}/{totalPlayers}</span>
          </div>
        </div>
        <div className="flex items-center">
          <Clock className="h-3.5 w-3.5 text-[#F9F9F9]/60 mr-1" />
          <div className="text-xs text-[#F9F9F9]/60">
            {formatTimeLeft(lobby.expiresAt)}
          </div>
        </div>
      </div>
      
      {/* Content */}
      <div className="p-4 flex-grow flex flex-col">
        {/* Owner and Lobby Code */}
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center">
            {lobby.owner.currentRank ? (
              <div className="w-8 h-8 rounded-full flex items-center justify-center mr-2 border border-[#383E3A]/60 overflow-hidden bg-[#0F1923]">
                <img 
                  src={`/src/assets/ranks/${lobby.owner.currentRank.split('_')[0]}.svg`} 
                  alt={formatRank(lobby.owner.currentRank)} 
                  className="w-6 h-6"
                />
              </div>
            ) : (
              <div className="w-8 h-8 rounded-full flex items-center justify-center mr-2 border border-[#383E3A]/60 overflow-hidden bg-[#0F1923]">
                <img src="/src/assets/ranks/unranked.svg" alt="Unranked" className="w-6 h-6" />
              </div>
            )}
            <div className="flex flex-col">
              <span className="font-medium text-sm">{lobby.owner.displayName || lobby.owner.username}</span>
              <span className="text-[10px] text-[#F9F9F9]/50">Lobby Owner</span>
            </div>
          </div>
          <div className="text-xs font-mono bg-[#0F1923] px-2 py-1 rounded border border-[#383E3A]/60">
            {lobby.code}
          </div>
        </div>
        
        {/* Description (if exists) */}
        {lobby.description && (
          <div className="mb-3 text-xs text-[#F9F9F9]/70 bg-[#0F1923]/50 p-2 rounded-sm border-l-2 border-[#FF4655]/50">
            {lobby.description}
          </div>
        )}
        
        {/* Rank Requirements and Join Button */}
        <div className="mt-auto pt-2 flex items-center justify-between">
          <div>
            <div className="text-xs text-[#F9F9F9]/50 mb-1 flex items-center">
              <User className="h-3 w-3 mr-1" /> Rank Requirements
            </div>
            <div className="flex items-center space-x-1">
              {lobby.disableRankRestrictions ? (
                <div className="text-emerald-400 text-xs font-medium">All Ranks Welcome</div>
              ) : lobby.minRank === 'unranked' && lobby.maxRank === 'radiant' ? (
                <div className="text-[#F9F9F9]/70 text-xs">Any Rank</div>
              ) : (
                <>
                  <div className="flex items-center px-2 py-0.5 rounded-sm bg-[#0F1923]/70 text-xs border border-[#383E3A]/30">
                    <img 
                      src={`/src/assets/ranks/${(lobby.minRank || 'unranked').split('_')[0]}.svg`} 
                      alt={formatRank(lobby.minRank || 'unranked')} 
                      className="w-4 h-4 mr-1"
                    />
                    {formatRank(lobby.minRank || 'unranked')}
                  </div>
                  <div className="text-[#F9F9F9]/30 text-sm">-</div>
                  <div className="flex items-center px-2 py-0.5 rounded-sm bg-[#0F1923]/70 text-xs border border-[#383E3A]/30">
                    <img 
                      src={`/src/assets/ranks/${(lobby.maxRank || 'radiant').split('_')[0]}.svg`} 
                      alt={formatRank(lobby.maxRank || 'radiant')} 
                      className="w-4 h-4 mr-1"
                    />
                    {formatRank(lobby.maxRank || 'radiant')}
                  </div>
                </>
              )}
            </div>
          </div>
          <Button 
            variant={isOwner ? "outline" : "default"}
            size="sm"
            className={isOwner 
              ? "border-[#383E3A]/60 text-[#F9F9F9]/70 cursor-not-allowed" 
              : !user
                ? "bg-[#1F2326] border border-[#FF4655] text-[#FF4655] hover:bg-[#FF4655]/10"
                : isFull
                  ? "bg-[#1F2326] border border-[#383E3A]/60 text-[#F9F9F9]/50 cursor-not-allowed"
                  : "bg-[#FF4655] hover:bg-[#FF4655]/90"
            }
            onClick={handleJoinLobby}
            disabled={joinMutation.isPending || !user || isOwner || isFull}
          >
            {joinMutation.isPending 
              ? "..."
              : isOwner 
                ? "YOUR LOBBY" 
                : isFull 
                  ? "FULL" 
                  : "JOIN LOBBY"
            }
          </Button>
        </div>
      </div>
    </Card>
  );
}
