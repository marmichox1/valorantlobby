// This file is now just a re-export of the .tsx file
// Keep this file to avoid breaking imports in other files
export * from './auth.tsx';