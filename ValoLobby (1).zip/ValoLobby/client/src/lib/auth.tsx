import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { type User, type LoginCredentials, type RegisterData } from "../../shared/schema";
import { apiRequest, queryClient } from "./queryClient";
import { useToast } from "../hooks/use-toast";

type AuthContextType = {
  user: User | null;
  loading: boolean;
  login: (credentials: LoginCredentials) => Promise<User | null>;
  register: (data: RegisterData) => Promise<User | null>;
  logout: () => Promise<void>;
  updateProfile: (userId: number, data: Partial<User>) => Promise<User | null>;
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  login: async () => null,
  register: async () => null,
  logout: async () => {},
  updateProfile: async () => null,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Login with email and password
  const login = async (credentials: LoginCredentials): Promise<User | null> => {
    try {
      const response = await apiRequest("POST", "/api/login", credentials);
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        toast({
          title: "Login successful",
          description: `Welcome back, ${userData.username}!`,
        });
        return userData;
      } else {
        const error = await response.json();
        toast({
          title: "Login failed",
          description: error.message || "Invalid email or password",
          variant: "destructive",
        });
        return null;
      }
    } catch (error) {
      console.error("Error logging in:", error);
      toast({
        title: "Login failed",
        description: "There was a problem connecting to the server",
        variant: "destructive",
      });
      return null;
    }
  };

  // Register a new user
  const register = async (data: RegisterData): Promise<User | null> => {
    try {
      const response = await apiRequest("POST", "/api/register", data);
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        toast({
          title: "Registration successful",
          description: `Welcome, ${userData.username}!`,
        });
        return userData;
      } else {
        const error = await response.json();
        toast({
          title: "Registration failed",
          description: error.message || "Could not create your account",
          variant: "destructive",
        });
        return null;
      }
    } catch (error) {
      console.error("Error registering:", error);
      toast({
        title: "Registration failed",
        description: "There was a problem connecting to the server",
        variant: "destructive",
      });
      return null;
    }
  };

  // Log out
  const logout = async (): Promise<void> => {
    try {
      const response = await apiRequest("POST", "/api/logout");
      
      if (response.ok) {
        setUser(null);
        // Clear user-related queries
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
        queryClient.invalidateQueries({ queryKey: ["/api/lobbies/user"] });
        toast({
          title: "Logged out",
          description: "You have been logged out successfully",
        });
      }
    } catch (error) {
      console.error("Error logging out:", error);
      toast({
        title: "Logout failed",
        description: "There was a problem logging out",
        variant: "destructive",
      });
    }
  };
  
  // Update user profile
  const updateProfile = async (userId: number, data: Partial<User>): Promise<User | null> => {
    try {
      const response = await apiRequest("PUT", `/api/users/${userId}`, data);
      
      if (response.ok) {
        const updatedUser = await response.json();
        setUser(updatedUser);
        toast({
          title: "Profile updated",
          description: "Your profile has been updated successfully",
        });
        return updatedUser;
      } else {
        const error = await response.json();
        toast({
          title: "Update failed",
          description: error.message || "Could not update your profile",
          variant: "destructive",
        });
        return null;
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      toast({
        title: "Update failed",
        description: "There was a problem connecting to the server",
        variant: "destructive",
      });
      return null;
    }
  };

  // Check if user is already logged in
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const response = await fetch("/api/user", {
          credentials: "include",
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
        }
      } catch (error) {
        console.error("Error fetching current user:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCurrentUser();
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}