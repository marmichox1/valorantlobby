import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
 
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Function to format a date to a relative time string (e.g. "10m left")
export function formatTimeLeft(date: Date | string): string {
  const now = new Date();
  const expiryDate = new Date(date);
  
  // Calculate difference in milliseconds
  const diffMs = expiryDate.getTime() - now.getTime();
  
  // If the date is in the past
  if (diffMs <= 0) {
    return "Expired";
  }
  
  // Convert to minutes
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  
  if (diffMinutes < 60) {
    return `${diffMinutes}m left`;
  }
  
  // Convert to hours and minutes
  const hours = Math.floor(diffMinutes / 60);
  const minutes = diffMinutes % 60;
  
  if (hours === 1) {
    return minutes > 0 ? `${hours}h ${minutes}m left` : `${hours}h left`;
  }
  
  return minutes > 0 ? `${hours}h ${minutes}m left` : `${hours}h left`;
}

// Get color for game type
export function getGameTypeColor(gameType: string): { bg: string, text: string, gradient: string } {
  switch (gameType) {
    case 'competitive':
      return { 
        bg: 'bg-[#FF4655]/10', 
        text: 'text-[#FF4655]',
        gradient: 'from-[#FF4655]/20'
      };
    case 'unrated':
      return { 
        bg: 'bg-[#28557F]/10', 
        text: 'text-[#28557F]',
        gradient: 'from-[#28557F]/20'
      };
    case 'spike_rush':
      return { 
        bg: 'bg-green-500/10', 
        text: 'text-green-500',
        gradient: 'from-green-500/20'
      };
    case 'swiftplay':
      return { 
        bg: 'bg-purple-500/10', 
        text: 'text-purple-500',
        gradient: 'from-purple-500/20'
      };
    case 'custom':
      return { 
        bg: 'bg-yellow-500/10', 
        text: 'text-yellow-500',
        gradient: 'from-yellow-500/20'
      };
    default:
      return { 
        bg: 'bg-gray-500/10', 
        text: 'text-gray-500',
        gradient: 'from-gray-500/20'
      };
  }
}

// Format game type for display
export function formatGameType(gameType: string): string {
  switch (gameType) {
    case 'competitive':
      return 'Competitive';
    case 'unrated':
      return 'Unrated';
    case 'spike_rush':
      return 'Spike Rush';
    case 'swiftplay':
      return 'Swiftplay';
    case 'custom':
      return 'Custom';
    default:
      return gameType;
  }
}

// Get color for rank
export function getRankColor(rank: string): { bg: string, text: string } {
  if (rank.startsWith('iron')) {
    return { bg: 'bg-[#72767D]/20', text: 'text-[#72767D]' };
  } else if (rank.startsWith('bronze')) {
    return { bg: 'bg-[#B97551]/20', text: 'text-[#B97551]' };
  } else if (rank.startsWith('silver')) {
    return { bg: 'bg-[#BEBEBE]/20', text: 'text-[#BEBEBE]' };
  } else if (rank.startsWith('gold')) {
    return { bg: 'bg-[#EFB058]/20', text: 'text-[#EFB058]' };
  } else if (rank.startsWith('platinum')) {
    return { bg: 'bg-[#4DF8E8]/20', text: 'text-[#4DF8E8]' };
  } else if (rank.startsWith('diamond')) {
    return { bg: 'bg-[#B073FF]/20', text: 'text-[#B073FF]' };
  } else if (rank.startsWith('ascendant')) {
    return { bg: 'bg-[#59BB7C]/20', text: 'text-[#59BB7C]' };
  } else if (rank.startsWith('immortal')) {
    return { bg: 'bg-[#EF4181]/20', text: 'text-[#EF4181]' };
  } else if (rank === 'radiant') {
    return { bg: 'bg-[#FFFFA8]/20', text: 'text-[#FFFFA8]' };
  } else {
    return { bg: 'bg-gray-500/20', text: 'text-gray-500' };
  }
}

// Format rank for display
export function formatRank(rank: string): string {
  if (rank === 'unranked') return 'Unranked';
  if (rank === 'radiant') return 'R';
  
  const parts = rank.split('_');
  if (parts.length === 2) {
    const [tier, level] = parts;
    return `${tier.charAt(0).toUpperCase()}${level}`;
  }
  
  return rank;
}

// Get numerical values for ranks to compare them
export function getRankValue(rank: string): number {
  const rankValues: Record<string, number> = {
    'unranked': 0,
    'iron_1': 1,
    'iron_2': 2,
    'iron_3': 3,
    'bronze_1': 4,
    'bronze_2': 5,
    'bronze_3': 6,
    'silver_1': 7,
    'silver_2': 8,
    'silver_3': 9,
    'gold_1': 10,
    'gold_2': 11,
    'gold_3': 12,
    'platinum_1': 13,
    'platinum_2': 14,
    'platinum_3': 15,
    'diamond_1': 16,
    'diamond_2': 17,
    'diamond_3': 18,
    'ascendant_1': 19,
    'ascendant_2': 20,
    'ascendant_3': 21,
    'immortal_1': 22,
    'immortal_2': 23,
    'immortal_3': 24,
    'radiant': 25
  };
  
  return rankValues[rank] || 0;
}

// Check if a rank is within a range
export function isRankInRange(rank: string, minRank: string | null, maxRank: string | null): boolean {
  const rankVal = getRankValue(rank);
  const minVal = getRankValue(minRank || 'unranked');
  const maxVal = getRankValue(maxRank || 'radiant');
  
  return rankVal >= minVal && rankVal <= maxVal;
}
