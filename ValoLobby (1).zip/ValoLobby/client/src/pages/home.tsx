import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import FilterSection from "@/components/lobbies/filter-section";
import LobbyCard from "@/components/lobbies/lobby-card";
import CreateLobbyForm from "@/components/lobbies/create-lobby-form";
import { useState } from "react";
import { type LobbyWithOwner } from "@shared/schema";
import { Loader2, AlertOctagon } from "lucide-react";
import { isRankInRange } from "@/lib/utils";

export default function Home() {
  const { user } = useAuth();
  
  // Filters state
  const [gameTypeFilter, setGameTypeFilter] = useState<string | null>(null);
  const [rankFilters, setRankFilters] = useState<string[]>([]);
  const [playersNeededFilter, setPlayersNeededFilter] = useState<number | null>(null);
  const [lobbyCodeFilter, setLobbyCodeFilter] = useState("");
  
  // Query for lobbies
  const { data: lobbies, isLoading, error } = useQuery<LobbyWithOwner[]>({
    queryKey: ["/api/lobbies"],
  });
  
  // Filter lobbies based on selected filters
  const filteredLobbies = lobbies?.filter((lobby) => {
    // Filter by game type
    if (gameTypeFilter && lobby.gameType !== gameTypeFilter) {
      return false;
    }
    
    // Filter by rank (if any rank filter is selected)
    if (rankFilters.length > 0) {
      // Check if lobby's rank range overlaps with any selected rank filter
      const hasMatchingRank = rankFilters.some(rank => {
        return isRankInRange(rank, lobby.minRank, lobby.maxRank);
      });
      
      if (!hasMatchingRank) {
        return false;
      }
    }
    
    // Filter by players needed
    if (playersNeededFilter !== null && lobby.playersNeeded !== playersNeededFilter) {
      return false;
    }
    
    // We no longer filter by lobby code since we removed that section
    
    return true;
  }) || [];
  
  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-10">
      <Tabs defaultValue="browse" className="w-full">
        <div className="flex justify-center mb-4">
          <TabsList className="bg-[#1F2326]/70 border border-[#383E3A]/30">
            <TabsTrigger value="browse" className="px-8 data-[state=active]:bg-[#FF4655] data-[state=active]:text-white">
              Browse Lobbies
            </TabsTrigger>
            <TabsTrigger value="create" className="px-8 data-[state=active]:bg-[#FF4655] data-[state=active]:text-white">
              Create Lobby
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="browse" className="mt-0">
          <FilterSection
            gameTypeFilter={gameTypeFilter}
            setGameTypeFilter={setGameTypeFilter}
            rankFilters={rankFilters}
            setRankFilters={setRankFilters}
            playersNeededFilter={playersNeededFilter}
            setPlayersNeededFilter={setPlayersNeededFilter}
            lobbyCodeFilter={lobbyCodeFilter}
            setLobbyCodeFilter={setLobbyCodeFilter}
          />
          
          {isLoading ? (
            <div className="py-16 text-center">
              <Loader2 className="animate-spin h-12 w-12 mx-auto text-[#FF4655]" />
              <p className="mt-4 text-[#F9F9F9]/70">Loading lobbies...</p>
            </div>
          ) : error ? (
            <div className="py-16 text-center">
              <AlertOctagon className="h-12 w-12 mx-auto text-[#FF4655]" />
              <p className="text-xl font-medium text-[#FF4655] mt-4">Error loading lobbies</p>
              <p className="mt-2 text-[#F9F9F9]/70">{(error as Error).message}</p>
            </div>
          ) : filteredLobbies.length === 0 ? (
            <div className="py-16 text-center border border-[#383E3A]/30 rounded-md mt-6 bg-[#1F2326]/30">
              <p className="text-xl font-medium">No lobbies found</p>
              <p className="mt-2 text-[#F9F9F9]/70">Try adjusting your filters or create a new lobby</p>
              
              {!user && (
                <p className="mt-4 text-[#F9F9F9]/70">
                  <span className="text-[#FF4655]">Sign in</span> to create your own lobby
                </p>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              {filteredLobbies.map(lobby => (
                <LobbyCard key={lobby.id} lobby={lobby} />
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="create" className="mt-0">
          <div className="max-w-2xl mx-auto">
            <CreateLobbyForm />
          </div>
        </TabsContent>
      </Tabs>
    </main>
  );
}
