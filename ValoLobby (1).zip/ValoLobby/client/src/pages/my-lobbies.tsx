import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import LobbyCard from "@/components/lobbies/lobby-card";
import { useAuth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { LobbyWithOwner } from "@shared/schema";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Trash2 } from "lucide-react";
import { Link } from "wouter";

export default function MyLobbies() {
  const { user, loading } = useAuth();
  const { toast } = useToast();
  
  const { data: myLobbies, isLoading, error } = useQuery<LobbyWithOwner[]>({
    queryKey: ["/api/lobbies/user", user?.id],
    enabled: !!user,
  });
  
  const deleteLobbyMutation = useMutation({
    mutationFn: async (lobbyId: number) => {
      if (!user) throw new Error("Not logged in");
      const res = await apiRequest("DELETE", `/api/lobbies/${lobbyId}`, { userId: user.id });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Lobby deleted",
        description: "Your lobby has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/lobbies/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/lobbies"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error deleting lobby",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleDeleteLobby = (lobbyId: number) => {
    deleteLobbyMutation.mutate(lobbyId);
  };
  
  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex justify-center">
        <div className="text-center">
          <svg className="animate-spin h-8 w-8 mx-auto text-[#FF4655]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="mt-4 text-[#F9F9F9]/70">Loading your lobbies...</p>
        </div>
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Card className="p-8 text-center">
          <h2 className="text-xl font-bold mb-2">Sign In Required</h2>
          <p className="text-[#F9F9F9]/70 mb-4">You need to sign in to view your lobbies</p>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">My Lobbies</h1>
        <Link href="/"><Button variant="outline">Browse All Lobbies</Button></Link>
      </div>
      
      {isLoading ? (
        <div className="py-12 text-center">
          <svg className="animate-spin h-8 w-8 mx-auto text-[#FF4655]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="mt-4 text-[#F9F9F9]/70">Loading your lobbies...</p>
        </div>
      ) : error ? (
        <div className="py-12 text-center">
          <p className="text-[#FF4655]">Error loading your lobbies</p>
          <p className="mt-2 text-[#F9F9F9]/70">{(error as Error).message}</p>
        </div>
      ) : !myLobbies || myLobbies.length === 0 ? (
        <div className="py-12 text-center border border-[#383E3A]/30 rounded-md bg-[#1F2326]/30">
          <p className="text-xl font-medium">You haven't created any lobbies yet</p>
          <p className="mt-2 text-[#F9F9F9]/70 mb-4">Create a lobby to find other players</p>
          <Link href="/"><Button variant="valorant">Create a Lobby</Button></Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {myLobbies.map(lobby => (
            <div key={lobby.id} className="relative">
              <LobbyCard lobby={lobby} />
              <Button
                variant="destructive"
                size="sm"
                className="absolute top-3 right-3 h-8 w-8 p-0"
                onClick={() => handleDeleteLobby(lobby.id)}
                disabled={deleteLobbyMutation.isPending}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
