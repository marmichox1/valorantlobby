import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { formatRank, getRankColor } from "@/lib/utils";
import { Rank } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Profile() {
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const [selectedRank, setSelectedRank] = useState<string>(user?.currentRank || Rank.UNRANKED);
  
  const updateRankMutation = useMutation({
    mutationFn: async (rank: string) => {
      if (!user) throw new Error("Not logged in");
      const res = await apiRequest("PUT", `/api/users/${user.id}`, { currentRank: rank });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Rank updated",
        description: "Your rank has been updated successfully",
      });
      // Invalidate user data to reflect changes in the UI
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating rank",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleUpdateRank = () => {
    updateRankMutation.mutate(selectedRank);
  };
  
  const rankOptions = Object.entries(Rank).map(([key, value]) => ({
    label: key.replace('_', ' ').split(' ').map((word: string) => 
      word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    ).join(' '),
    value
  }));
  
  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex justify-center">
        <div className="text-center">
          <svg className="animate-spin h-8 w-8 mx-auto text-[#FF4655]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="mt-4 text-[#F9F9F9]/70">Loading profile...</p>
        </div>
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Card className="max-w-md mx-auto">
          <CardHeader className="text-center">
            <CardTitle>Sign In Required</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-[#F9F9F9]/70 mb-4">You need to sign in to view your profile</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardHeader className="text-center">
            <div className="flex flex-col items-center">
              {user.photoURL ? (
                <img 
                  src={user.photoURL} 
                  alt={user.displayName || user.username} 
                  className="h-24 w-24 rounded-full mb-4" 
                />
              ) : (
                <div className="h-24 w-24 rounded-full bg-[#1F2326] flex items-center justify-center text-[#F9F9F9] text-2xl mb-4">
                  {(user.displayName || user.username || "User").charAt(0).toUpperCase()}
                </div>
              )}
              <CardTitle className="text-xl">{user.displayName || user.username}</CardTitle>
              <div className="mt-2 text-[#F9F9F9]/70 text-sm">{user.email}</div>
            </div>
          </CardHeader>
        </Card>
        
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Valorant Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="text-[#F9F9F9]/80 text-sm font-medium mb-2">Current Rank</h3>
              <div className="flex items-center mb-4">
                {user.currentRank ? (
                  <>
                    <div className="w-10 h-10 rounded-full flex items-center justify-center mr-2 border border-[#383E3A]/60 overflow-hidden bg-[#0F1923]">
                      <img 
                        src={`/src/assets/ranks/${user.currentRank.split('_')[0]}.svg`} 
                        alt={formatRank(user.currentRank)} 
                        className="w-8 h-8"
                      />
                    </div>
                    <span className="text-[#F9F9F9]">
                      {user.currentRank.replace('_', ' ').split(' ').map((word: string) => 
                        word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
                      ).join(' ')}
                    </span>
                  </>
                ) : (
                  <>
                    <div className="w-10 h-10 rounded-full flex items-center justify-center mr-2 border border-[#383E3A]/60 overflow-hidden bg-[#0F1923]">
                      <img src="/src/assets/ranks/unranked.svg" alt="Unranked" className="w-8 h-8" />
                    </div>
                    <span className="text-[#F9F9F9]">Unranked</span>
                  </>
                )}
              </div>
              
              <h3 className="text-[#F9F9F9]/80 text-sm font-medium mb-2">Update Rank</h3>
              <div className="flex flex-col sm:flex-row gap-4">
                <Select
                  value={selectedRank}
                  onValueChange={setSelectedRank}
                >
                  <SelectTrigger className="w-full sm:w-64">
                    <div className="flex items-center">
                      <div className="w-6 h-6 mr-2 flex items-center justify-center">
                        <img 
                          src={`/src/assets/ranks/${selectedRank.split('_')[0]}.svg`} 
                          alt={selectedRank}
                          className="h-5 w-5"
                        />
                      </div>
                      <SelectValue placeholder="Select your rank" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    {rankOptions.map((rank) => (
                      <SelectItem key={rank.value} value={rank.value} className="flex items-center">
                        <div className="flex items-center">
                          <div className="w-6 h-6 mr-2 flex items-center justify-center">
                            <img 
                              src={`/src/assets/ranks/${rank.value.split('_')[0]}.svg`} 
                              alt={rank.label}
                              className="h-5 w-5"
                            />
                          </div>
                          {rank.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Button 
                  variant="valorant" 
                  onClick={handleUpdateRank}
                  disabled={updateRankMutation.isPending || selectedRank === user.currentRank}
                >
                  {updateRankMutation.isPending ? "Updating..." : "Update Rank"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
