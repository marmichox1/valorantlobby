import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertLobbySchema, 
  loginSchema, 
  registerSchema, 
  GameType, 
  Rank,
  type User 
} from "@shared/schema";
import crypto from "crypto";

// Extend the session type definition
declare module 'express-session' {
  interface SessionData {
    userId: number;
  }
}

// Generate a random 6-character lobby code
function generateLobbyCode(): string {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

// Calculate expiration time
function calculateExpirationTime(minutes: number): Date {
  const expiresAt = new Date();
  expiresAt.setMinutes(expiresAt.getMinutes() + minutes);
  return expiresAt;
}

// Middleware to hash passwords
function hashPassword(password: string): string {
  // In a real app, use a better hashing algorithm with salt
  // This is just a simplified version for the demo
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Authentication middleware
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.session.userId) {
    return next();
  }
  res.status(401).json({ message: 'Unauthorized' });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || 'valorant-lobby-finder-secret',
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: { 
      secure: process.env.NODE_ENV === 'production',
      maxAge: 1000 * 60 * 60 * 24 * 7 // 1 week
    }
  }));
  
  // Set up API routes
  const apiRouter = express.Router();
  
  // Auth routes
  apiRouter.post('/register', async (req: Request, res: Response) => {
    try {
      const userData = registerSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: 'Email already in use' });
      }
      
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: 'Username already taken' });
      }
      
      // Create the user with hashed password
      const newUser = await storage.createUser({
        ...userData,
        password: hashPassword(userData.password),
      });
      
      // Set session data
      req.session.userId = newUser.id;
      
      // Return user without password
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid registration data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to register user' });
    }
  });

  apiRouter.post('/login', async (req: Request, res: Response) => {
    try {
      const credentials = loginSchema.parse(req.body);
      
      // Validate credentials
      const user = await storage.validateCredentials(
        credentials.email, 
        credentials.password  // Pass the raw password - validateCredentials will hash it
      );
      
      if (!user) {
        return res.status(401).json({ message: 'Invalid email or password' });
      }
      
      // Set session data
      req.session.userId = user.id;
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid login data', errors: error.errors });
      }
      res.status(500).json({ message: 'Login failed' });
    }
  });

  apiRouter.post('/logout', (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: 'Failed to logout' });
      }
      res.clearCookie('connect.sid');
      res.json({ message: 'Logged out successfully' });
    });
  });

  apiRouter.get('/user', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId as number;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get user data' });
    }
  });

  // User routes
  apiRouter.get('/users/:id', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get user' });
    }
  });

  apiRouter.put('/users/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const sessionUserId = req.session.userId as number;
      
      // Only allow users to update their own profile
      if (userId !== sessionUserId) {
        return res.status(403).json({ message: 'You can only update your own profile' });
      }
      
      const userData = req.body;
      
      // Don't allow password updates through this endpoint
      if (userData.password) {
        delete userData.password;
      }
      
      const updatedUser = await storage.updateUser(userId, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user' });
    }
  });

  // Lobby routes
  apiRouter.post('/lobbies', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId as number;
      
      // Extend schema to handle derived fields
      const lobbyDataSchema = z.object({
        gameType: z.nativeEnum(GameType),
        playersNeeded: z.number().min(1).max(4),
        minRank: z.nativeEnum(Rank).optional(),
        maxRank: z.nativeEnum(Rank).optional(),
        disableRankRestrictions: z.boolean().default(false),
        code: z.string().length(6).regex(/^[A-Z0-9]+$/).optional(),
        description: z.string().optional(),
        expirationMinutes: z.number().default(60),
      });
      
      const lobbyData = lobbyDataSchema.parse(req.body);
      
      // Generate unique code
      let code;
      let existingLobby;
      do {
        code = generateLobbyCode();
        existingLobby = await storage.getLobbyByCode(code);
      } while (existingLobby);
      
      const expiresAt = calculateExpirationTime(lobbyData.expirationMinutes);
      
      // Use user-provided code or generated one
      const finalCode = lobbyData.code || code;
      
      // Create the lobby
      const lobby = await storage.createLobby({
        code: finalCode,
        ownerId: userId,
        gameType: lobbyData.gameType,
        playersNeeded: lobbyData.playersNeeded,
        minRank: lobbyData.minRank || Rank.UNRANKED,
        maxRank: lobbyData.maxRank || Rank.RADIANT,
        disableRankRestrictions: lobbyData.disableRankRestrictions,
        description: lobbyData.description || "",
        expiresAt,
      });
      
      // Add owner as first player
      await storage.addPlayerToLobby({
        lobbyId: lobby.id,
        userId,
      });
      
      res.status(201).json(lobby);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid lobby data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create lobby' });
    }
  });

  apiRouter.get('/lobbies', async (req: Request, res: Response) => {
    try {
      const lobbies = await storage.getLobbiesWithDetails();
      
      // Filter out expired lobbies
      const now = new Date();
      const activeLobbies = lobbies.filter(lobby => new Date(lobby.expiresAt) > now);
      
      res.json(activeLobbies);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get lobbies' });
    }
  });

  apiRouter.get('/lobbies/user', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId as number;
      const lobbies = await storage.getLobbiesByOwner(userId);
      
      // Get detailed info for each lobby
      const detailedLobbies = [];
      for (const lobby of lobbies) {
        const owner = await storage.getUser(lobby.ownerId);
        const players = await storage.getLobbyPlayers(lobby.id);
        
        if (owner) {
          // Exclude password from owner
          const { password, ...ownerWithoutPassword } = owner;
          
          detailedLobbies.push({
            ...lobby,
            owner: ownerWithoutPassword,
            currentPlayers: players.length
          });
        }
      }
      
      res.json(detailedLobbies);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get user lobbies' });
    }
  });

  apiRouter.get('/lobbies/:code', async (req: Request, res: Response) => {
    try {
      const { code } = req.params;
      const lobby = await storage.getLobbyByCode(code);
      
      if (!lobby) {
        return res.status(404).json({ message: 'Lobby not found' });
      }
      
      const owner = await storage.getUser(lobby.ownerId);
      const players = await storage.getLobbyPlayers(lobby.id);
      
      if (!owner) {
        return res.status(404).json({ message: 'Lobby owner not found' });
      }
      
      // Exclude password from owner
      const { password, ...ownerWithoutPassword } = owner;
      
      res.json({
        ...lobby,
        owner: ownerWithoutPassword,
        currentPlayers: players.length
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to get lobby' });
    }
  });

  apiRouter.post('/lobbies/:lobbyId/join', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const lobbyId = parseInt(req.params.lobbyId);
      const userId = req.session.userId as number;
      
      const lobby = await storage.getLobby(lobbyId);
      if (!lobby) {
        return res.status(404).json({ message: 'Lobby not found' });
      }
      
      // Check if lobby is expired
      if (new Date(lobby.expiresAt) < new Date()) {
        return res.status(400).json({ message: 'Lobby has expired' });
      }
      
      // Check if user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Check if user's rank meets requirements (skip if rank restrictions are disabled)
      if (!lobby.disableRankRestrictions) {
        const userRank = user.currentRank || Rank.UNRANKED;
        const minRank = lobby.minRank || Rank.UNRANKED;
        const maxRank = lobby.maxRank || Rank.RADIANT;
        
        if (userRank < minRank || userRank > maxRank) {
          return res.status(400).json({ message: 'Your rank does not meet the requirements' });
        }
      }
      
      // Check if lobby is full
      const existingPlayers = await storage.getLobbyPlayers(lobbyId);
      if (existingPlayers.length >= lobby.playersNeeded + 1) { // +1 for the owner
        return res.status(400).json({ message: 'Lobby is full' });
      }
      
      // Check if user is already in the lobby
      const isAlreadyInLobby = existingPlayers.some(player => player.userId === userId);
      if (isAlreadyInLobby) {
        return res.status(400).json({ message: 'You are already in this lobby' });
      }
      
      const lobbyPlayer = await storage.addPlayerToLobby({ lobbyId, userId });
      res.status(201).json(lobbyPlayer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to join lobby' });
    }
  });

  apiRouter.delete('/lobbies/:lobbyId/leave', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const lobbyId = parseInt(req.params.lobbyId);
      const userId = req.session.userId as number;
      
      const lobby = await storage.getLobby(lobbyId);
      if (!lobby) {
        return res.status(404).json({ message: 'Lobby not found' });
      }
      
      // Check if user is the owner (owners can't leave their own lobby)
      if (lobby.ownerId === userId) {
        return res.status(400).json({ message: 'Lobby owners cannot leave their own lobby. Delete the lobby instead.' });
      }
      
      const success = await storage.removePlayerFromLobby(lobbyId, userId);
      
      if (!success) {
        return res.status(404).json({ message: 'User is not in this lobby' });
      }
      
      res.json({ message: 'Successfully left the lobby' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to leave lobby' });
    }
  });

  apiRouter.delete('/lobbies/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const lobbyId = parseInt(req.params.id);
      const userId = req.session.userId as number;
      
      const lobby = await storage.getLobby(lobbyId);
      if (!lobby) {
        return res.status(404).json({ message: 'Lobby not found' });
      }
      
      // Check if user is the owner
      if (lobby.ownerId !== userId) {
        return res.status(403).json({ message: 'Only the lobby owner can delete it' });
      }
      
      const success = await storage.deleteLobby(lobbyId);
      
      if (!success) {
        return res.status(500).json({ message: 'Failed to delete lobby' });
      }
      
      res.json({ message: 'Lobby deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete lobby' });
    }
  });

  app.use('/api', apiRouter);
  
  const httpServer = createServer(app);
  return httpServer;
}
