import { 
  users, type User, type InsertUser,
  lobbies, type Lobby, type InsertLobby, type LobbyWithOwner,
  lobbyPlayers, type LobbyPlayer, type InsertLobbyPlayer,
  sessions, type Session, type InsertSession
} from "@shared/schema";
import { db } from "./db";
import { eq, and, sql } from "drizzle-orm";
import * as crypto from "crypto";
import session from "express-session";
import pg from "pg";
import memorystore from 'memorystore';

const { Pool } = pg;

// Interface for storage operations
export interface IStorage {
  // Session management
  sessionStore: session.Store;
  createSession(userId: number): Promise<Session>;
  getSessionByToken(token: string): Promise<Session | undefined>;
  deleteSession(token: string): Promise<boolean>;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  validateCredentials(email: string, password: string): Promise<User | undefined>;
  
  // Lobby operations
  getLobby(id: number): Promise<Lobby | undefined>;
  getLobbyByCode(code: string): Promise<Lobby | undefined>;
  createLobby(lobby: InsertLobby): Promise<Lobby>;
  deleteLobby(id: number): Promise<boolean>;
  updateLobby(id: number, lobbyData: Partial<Lobby>): Promise<Lobby | undefined>;
  getAllLobbies(): Promise<Lobby[]>;
  getLobbiesByOwner(ownerId: number): Promise<Lobby[]>;
  
  // Lobby player operations
  addPlayerToLobby(lobbyPlayer: InsertLobbyPlayer): Promise<LobbyPlayer>;
  removePlayerFromLobby(lobbyId: number, userId: number): Promise<boolean>;
  getLobbyPlayers(lobbyId: number): Promise<LobbyPlayer[]>;
  getLobbiesWithDetails(): Promise<LobbyWithOwner[]>;
}

// Create database connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Initialize in-memory session store
const MemoryStore = memorystore(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    // Initialize in-memory session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  // Session operations
  async createSession(userId: number): Promise<Session> {
    const token = crypto.randomBytes(64).toString('hex');
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 days from now
    
    const [newSession] = await db.insert(sessions)
      .values({ userId, token, expiresAt })
      .returning();
      
    return newSession;
  }
  
  async getSessionByToken(token: string): Promise<Session | undefined> {
    const [session] = await db.select()
      .from(sessions)
      .where(eq(sessions.token, token));
      
    return session;
  }
  
  async deleteSession(token: string): Promise<boolean> {
    const result = await db.delete(sessions)
      .where(eq(sessions.token, token));
    
    return true; // We'll assume the operation was successful
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select()
      .from(users)
      .where(eq(users.id, id));
      
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select()
      .from(users)
      .where(eq(users.email, email));
      
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select()
      .from(users)
      .where(eq(users.username, username));
      
    return user;
  }

  async validateCredentials(email: string, password: string): Promise<User | undefined> {
    const user = await this.getUserByEmail(email);
    if (!user) return undefined;
    
    // Hash the provided password before comparing
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
    
    // Compare hashed passwords
    if (user.password !== hashedPassword) return undefined;
    
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users)
      .values(insertUser)
      .returning();
      
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
      
    return updatedUser;
  }

  // Lobby operations
  async getLobby(id: number): Promise<Lobby | undefined> {
    const [lobby] = await db.select()
      .from(lobbies)
      .where(eq(lobbies.id, id));
      
    return lobby;
  }

  async getLobbyByCode(code: string): Promise<Lobby | undefined> {
    const [lobby] = await db.select()
      .from(lobbies)
      .where(eq(lobbies.code, code));
      
    return lobby;
  }

  async createLobby(insertLobby: InsertLobby): Promise<Lobby> {
    const [lobby] = await db.insert(lobbies)
      .values(insertLobby)
      .returning();
      
    return lobby;
  }

  async deleteLobby(id: number): Promise<boolean> {
    // First delete all lobby players
    await db.delete(lobbyPlayers)
      .where(eq(lobbyPlayers.lobbyId, id));
      
    // Then delete the lobby
    const result = await db.delete(lobbies)
      .where(eq(lobbies.id, id));
      
    return true; // We'll assume the operation was successful
  }

  async updateLobby(id: number, lobbyData: Partial<Lobby>): Promise<Lobby | undefined> {
    const [updatedLobby] = await db.update(lobbies)
      .set(lobbyData)
      .where(eq(lobbies.id, id))
      .returning();
      
    return updatedLobby;
  }

  async getAllLobbies(): Promise<Lobby[]> {
    return await db.select()
      .from(lobbies);
  }

  async getLobbiesByOwner(ownerId: number): Promise<Lobby[]> {
    return await db.select()
      .from(lobbies)
      .where(eq(lobbies.ownerId, ownerId));
  }

  // Lobby player operations
  async addPlayerToLobby(insertLobbyPlayer: InsertLobbyPlayer): Promise<LobbyPlayer> {
    const [lobbyPlayer] = await db.insert(lobbyPlayers)
      .values(insertLobbyPlayer)
      .returning();
      
    return lobbyPlayer;
  }

  async removePlayerFromLobby(lobbyId: number, userId: number): Promise<boolean> {
    const result = await db.delete(lobbyPlayers)
      .where(and(
        eq(lobbyPlayers.lobbyId, lobbyId),
        eq(lobbyPlayers.userId, userId)
      ));
      
    return true; // We'll assume the operation was successful
  }

  async getLobbyPlayers(lobbyId: number): Promise<LobbyPlayer[]> {
    return await db.select()
      .from(lobbyPlayers)
      .where(eq(lobbyPlayers.lobbyId, lobbyId));
  }

  async getLobbiesWithDetails(): Promise<LobbyWithOwner[]> {
    const allLobbies = await this.getAllLobbies();
    const lobbiesWithDetails: LobbyWithOwner[] = [];
    
    for (const lobby of allLobbies) {
      const owner = await this.getUser(lobby.ownerId);
      const players = await this.getLobbyPlayers(lobby.id);
      
      if (owner) {
        lobbiesWithDetails.push({
          ...lobby,
          owner,
          currentPlayers: players.length
        });
      }
    }
    
    return lobbiesWithDetails;
  }
}

export const storage = new DatabaseStorage();
