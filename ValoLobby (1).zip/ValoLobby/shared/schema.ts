import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define the Game Types
export enum GameType {
  UNRATED = "unrated",
  COMPETITIVE = "competitive",
  SPIKE_RUSH = "spike_rush",
  SWIFTPLAY = "swiftplay",
  CUSTOM = "custom"
}

// Define the Ranks
export enum Rank {
  UNRANKED = "unranked",
  IRON_1 = "iron_1",
  IRON_2 = "iron_2",
  IRON_3 = "iron_3",
  BRONZE_1 = "bronze_1",
  BRONZE_2 = "bronze_2",
  BRONZE_3 = "bronze_3",
  SILVER_1 = "silver_1",
  SILVER_2 = "silver_2",
  SILVER_3 = "silver_3",
  GOLD_1 = "gold_1",
  GOLD_2 = "gold_2",
  GOLD_3 = "gold_3",
  PLATINUM_1 = "platinum_1",
  PLATINUM_2 = "platinum_2",
  PLATINUM_3 = "platinum_3",
  DIAMOND_1 = "diamond_1",
  DIAMOND_2 = "diamond_2",
  DIAMOND_3 = "diamond_3",
  ASCENDANT_1 = "ascendant_1",
  ASCENDANT_2 = "ascendant_2",
  ASCENDANT_3 = "ascendant_3",
  IMMORTAL_1 = "immortal_1",
  IMMORTAL_2 = "immortal_2",
  IMMORTAL_3 = "immortal_3",
  RADIANT = "radiant"
}

// Base users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  photoURL: text("photo_url"),
  currentRank: text("current_rank").default(Rank.UNRANKED),
  createdAt: timestamp("created_at").defaultNow(),
});

// Lobbies table
export const lobbies = pgTable("lobbies", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 6 }).notNull().unique(),
  ownerId: integer("owner_id").notNull().references(() => users.id),
  gameType: text("game_type").notNull(),
  playersNeeded: integer("players_needed").notNull(),
  minRank: text("min_rank").default(Rank.UNRANKED),
  maxRank: text("max_rank").default(Rank.RADIANT),
  disableRankRestrictions: boolean("disable_rank_restrictions").default(false),
  description: text("description"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Lobby players (users in lobbies)
export const lobbyPlayers = pgTable("lobby_players", {
  id: serial("id").primaryKey(),
  lobbyId: integer("lobby_id").notNull().references(() => lobbies.id),
  userId: integer("user_id").notNull().references(() => users.id),
  joinedAt: timestamp("joined_at").defaultNow(),
});

// Sessions table for auth
export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations are defined through foreign keys in the table definitions above

// Define insertion schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertLobbySchema = createInsertSchema(lobbies).omit({ id: true, createdAt: true });
export const insertLobbyPlayerSchema = createInsertSchema(lobbyPlayers).omit({ id: true, joinedAt: true });
export const insertSessionSchema = createInsertSchema(sessions).omit({ id: true, createdAt: true });

// Login schema
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

// Registration schema for validation
export const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(6),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

// Define types for insertion
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertLobby = z.infer<typeof insertLobbySchema>;
export type InsertLobbyPlayer = z.infer<typeof insertLobbyPlayerSchema>;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type LoginCredentials = z.infer<typeof loginSchema>;
export type RegisterData = z.infer<typeof registerSchema>;

// Define types for selection
export type User = typeof users.$inferSelect;
export type Lobby = typeof lobbies.$inferSelect;
export type LobbyPlayer = typeof lobbyPlayers.$inferSelect;
export type Session = typeof sessions.$inferSelect;

// Extended lobby type with owner information
export type LobbyWithOwner = Lobby & {
  owner: User;
  currentPlayers: number;
};
